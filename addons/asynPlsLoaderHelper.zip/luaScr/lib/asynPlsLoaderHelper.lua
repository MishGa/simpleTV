-- (12/5/20)
function asynPlsLoaderHelperCancelPressed(ObjectName,EventName,data)
 if data.button  == 1 then
   if     m_simpleTV.User ~= nil 
	  and m_simpleTV.User.APLS then
	m_simpleTV.User.APLS.CancelByUser  = true
   end
 end
end

local base = _G
module ('asynPlsLoaderHelper')

------------------------------------------------------------------
--static init
------------------------------------------------------------------
	local DefaultMessage, Cancelled, cancelled, Done, press_any_key_for_cancel, cancel
	if base.m_simpleTV.Interface.GetLanguage() == 'ru' then
		DefaultMessage = 'загрузка'
		Cancelled = 'остановлено'
		cancelled = ' отменено '
		Done = 'завершено'
		press_any_key_for_cancel = 'остановить'
		cancel = ' отмена '
	else
		DefaultMessage = 'Playlist loading'
		Cancelled = 'Cancelled'
		cancelled = ' cancelled '
		Done = 'Done'
		press_any_key_for_cancel = 'cancel'
		cancel = ' cancel '
	end
------------------------------------------------------------------
------------------------------------------------------------------
function ARGB(A,R,G,B)
  local a = A*256*256*256+R*256*256+G*256+B
  if A<128 then return a end
  return a - 4294967296 
 end
------------------------------------------------------------------
local function ShowWaitWindow(params)
 --base.m_simpleTV.OSD.SetElementDebugMode(true)
   
 local AddElement = base.m_simpleTV.OSD.AddElement
 local ControlElement = base.m_simpleTV.OSD.ControlElement
   
 local q = {}
 q.id = 'ID_APLS_WAIT'
 q.cx=-100
 q.cy=-100
 q.class="DIV"
 q.once=1
 if base.m_simpleTV.Common.GetVersion() >= 830 then
    q.zorder=100
 else 		
   q.zorder=0
 end
 AddElement(q)
   
 q={}
 q.id = 'ID_APLS_WAIT_TEXT'
 q.cx=0
 q.cy=0
 q.class="TEXT"
 q.align = 0x0202
 q.top=130
 q.color = (params.MessageColor or ARGB(0xFF,0xD0,0xD0,0xD0))
 q.font_italic =0
 q.font_addheight=8
 q.padding=17
 q.textparam = 1+4 
 q.text = (params.Message or DefaultMessage) .. '  ............\n ' 
 q.background = 0
 q.backcolor0 = ARGB(0x90,0,0,0)
 
 if base.m_simpleTV.Common.GetVersion() >= 830 then
	q.visible = false
	q.deleteOnHide = true
	q.deleteParentOnDelete = true
	
    q.shadowWidth = 8
	q.shadowBlur = 7
	q.shadowFillOffset = 0
	q.shadowOffsetX = 2
	q.shadowOffsetY = 2
	q.shadowFillType = 0
	q.shadowColor0 = ARGB(100,10,10,10)
	q.shadowColor1 = ARGB(120,255,10,10)
		
	q.fadeTime = 500
	q.hideTime = 3000
	q.showTime = 300	
	q.showEffect = 1
	q.zoomTypePointShow = 0
	q.showEasingCurve = 40	
	q.hideEffect = 3
	q.zoomTypePointHide = 6
  else 		
 end
  
 AddElement(q,'ID_APLS_WAIT')
 ControlElement('ID_APLS_WAIT_TEXT','SET_SIZE_LOCK')
 
 if params.ProgressEnabled==true then
  q={}
  q.id = 'ID_APLS_WAIT_PROGRESS_BORDER'
  q.cx=-100
  q.cy=10
  q.top=-12
  q.align = 0x0101
  q.class="DIV"
  q.borderwidth=1
  q.bordercolor = (params.ProgressBorderColor or ARGB(0x80,200,200,200))
  q.zorder=1
  
  if base.m_simpleTV.Common.GetVersion() >= 830 then

    q.shadowWidth = 7
	q.shadowBlur = 6
	q.shadowColor0 = ARGB(100,250,10,10)

  end
  AddElement(q,'ID_APLS_WAIT_TEXT')
 
  q={}
  q.id = 'ID_APLS_WAIT_PROGRESS'
  q.cx=0
  q.cy=8
  q.align = 0x0201
  q.class="DIV"
  q.background = 0
  q.backcolor0 = (params.ProgressColor or ARGB(0xE0,50,50,240))
  AddElement(q,'ID_APLS_WAIT_PROGRESS_BORDER')
 end 
 
 q={}
 q.id = 'ID_APLS_WAIT_TEXT1'
 q.cx=-100
 q.cy=0
 q.top=-4
 q.class="TEXT"
 q.align = 0x0402
 q.color = (params.CancelColor or ARGB(0xFF,0xB8,0xB8,0x28))
 q.textparam = 1+4 
 if base.m_simpleTV.Common.GetVersion() >= 830 then
	q.text = cancel
	
	q.isInteractive = true
	q.mouseReleaseEventFunction = 'asynPlsLoaderHelperCancelPressed'
	q.cursorShape = 13
	
	q.background = 0  
	q.backcolor0 = ARGB(200,128,128,128)
	q.borderwidth = 2
	q.bordercolor = ARGB(200,128,128,128)
	
	q.color_UnderMouse = base.m_simpleTV.Interface.ColorBrightness(q.color,50)
		
	q.background_UnderMouse = 0  
	q.backcolor0_UnderMouse = base.m_simpleTV.Interface.ColorBrightness(q.backcolor0,50)
    q.backcolor0_Pressed = base.m_simpleTV.Interface.ColorBrightness(q.backcolor0,-50)
		
	q.font_addheight=2	
	-- q.font_underline_UnderMouse = 1
 else 
   q.text = press_any_key_for_cancel
   q.font_italic =1
   q.font_addheight=4
 end
 AddElement(q,'ID_APLS_WAIT_TEXT')
  
 if params.delayedShow == 0 then
	ControlElement('ID_APLS_WAIT_TEXT','SET_VISIBLE',true,true)
 end	
 
end
--------------------------------------------------------------------
local function HideWaitWindow()
 if base.m_simpleTV.Common.GetVersion() >= 830 then
		base.m_simpleTV.OSD.ControlElement('ID_APLS_WAIT_TEXT','SET_VISIBLE',false,true)
  else base.m_simpleTV.OSD.RemoveElement('ID_APLS_WAIT') 
 end
end
--------------------------------------------------------------------
--------------------------------------------------------------------
function APLS_GetAsynPl(session,rc,answer,userValue)
 
 local ret = base.m_simpleTV.User.APLS.Params.Callback(session,rc,answer,userstring,base.m_simpleTV.User.APLS.Params)
 if ret == nil or ret.Cancel==true then
    base.m_simpleTV.User.APLS.Cancel  = true
	return
  end
    
 if ret.Done==true then     
	 base.m_simpleTV.OSD.ControlElement('ID_APLS_WAIT_TEXT','SET_VALUE_TEXT',Done..'\n ')
	 if base.m_simpleTV.User.APLS.Params.ProgressEnabled == true then
	   base.m_simpleTV.OSD.ControlElement('ID_APLS_WAIT_PROGRESS','SET_BCOLOR0',ARGB(0x90,0x20,0xA0,0x20))
	   base.m_simpleTV.OSD.ControlElement('ID_APLS_WAIT_PROGRESS','SET_SIZE_CX', -100  )
     end	   

	 base.m_simpleTV.User.APLS.Cancel  = true
	 base.m_simpleTV.Common.Sleep(500)
	return
 end
     
 if ret.request == nil then
    base.m_simpleTV.User.APLS.Cancel  = true
	return
 end
 
 ret.request.callback='_MainPlsAsynCallback'
 if base.m_simpleTV.Http.RequestA(session,ret.request) ~= true then
    base.m_simpleTV.User.APLS.Cancel  = true
	return
 end
 
 if ret.Count ~= nil then
   base.m_simpleTV.OSD.ControlElement('ID_APLS_WAIT_TEXT','SET_VALUE_TEXT',(base.m_simpleTV.User.APLS.Params.Message or DefaultMessage) 
											 .. ' - ' .. ret.Count ..'\n ')
   
   --local err,cx,cy = base.m_simpleTV.OSD.ControlElement('ID_APLS_WAIT_TEXT','GET_SIZE')
   --local err1,left,top,right,bottom = base.m_simpleTV.OSD.ControlElement('ID_APLS_WAIT_TEXT','GET_RECT')
   --local err2,cx2,cy2 = base.m_simpleTV.OSD.ControlElement('ID_APLS_WAIT_TEXT','GET_VALUE_TEXT_SIZE')
   --if err then  base.debug_in_file('cx=' .. cx .. ' cy=' .. cy .. '\n') end
   --if err1 then  base.debug_in_file('left=' .. left .. ' top=' .. top .. ' right=' .. right  .. ' bottom=' .. bottom .. '\n') end
   --if err2 then  base.debug_in_file('cx2=' .. cx2 .. ' cy2=' .. cy2 .. '\n') end
   
 end
 
 if base.m_simpleTV.User.APLS.Params.ProgressEnabled == true 
    and ret.Progress~=nil and ret.Progress >= 0 and ret.Progress<=1 
    then
    base.m_simpleTV.OSD.ControlElement('ID_APLS_WAIT_PROGRESS','SET_SIZE_CX', -100 * ret.Progress )
 end   
 
end
--------------------------------------------------------------------
--------------------------------------------------------------------
function Work(session,request,params)
 
 if params==nil or params.Callback == nil then return end
 if params.delayedShow == nil then
    params.delayedShow = 0
 end
  
 if base.m_simpleTV.User==nil then base.m_simpleTV.User={} end
 base.m_simpleTV.User.APLS = {}
 base.m_simpleTV.User.APLS.Cancel  = false
 base.m_simpleTV.User.APLS.CancelByUser  = false
 base.m_simpleTV.User.APLS.Params = params
 
 ShowWaitWindow(params)
 base._MainPlsAsynCallback = APLS_GetAsynPl
 request.callback='_MainPlsAsynCallback'
   
 if base.m_simpleTV.Http.RequestA(session,request) ~=true then return  end

 local delayedCount = 0
 while true do
	if base.m_simpleTV.User.APLS.Cancel == true then break end
	
	if base.m_simpleTV.Common.GetVersion() >= 830 then
	 if   base.m_simpleTV.Common.IsInterruptionRequested()
	   or base.m_simpleTV.Common.IsExecutionCanceled()
	   or base.m_simpleTV.OSD.ControlElement('ID_APLS_WAIT','GET_VISIBLE') ~= true
	  then 
	   HideWaitWindow() 
	   return false 
	 end
	 
	 local e,key,action = base.m_simpleTV.Common.WaitUserInput(250)
	 if e == 1 and (key ~=  0 or action == 37) then
		base.m_simpleTV.User.APLS.CancelByUser = true
	 end
	 
	 if base.m_simpleTV.User.APLS.CancelByUser == true then 
	   base.m_simpleTV.OSD.ControlElement('ID_APLS_WAIT_TEXT1','SET_VALUE_TEXT',cancelled,true)
	   base.m_simpleTV.OSD.ControlElement('ID_APLS_WAIT_TEXT1','SET_VALUE_TCOLOR',ARGB(250,255,0,0))
	   base.m_simpleTV.OSD.ControlElement('ID_APLS_WAIT_TEXT1','SET_VALUE_TCOLOR_UNDERMOUSE',ARGB(250,255,0,0))
	   base.m_simpleTV.OSD.ControlElement('ID_APLS_WAIT_TEXT1','SET_VALUE_TCOLOR_PRESSED',ARGB(250,255,0,0))
	   base.m_simpleTV.Http.RequestCancel(session)
	   local ret,visible = base.m_simpleTV.OSD.ControlElement('ID_APLS_WAIT_TEXT','GET_VISIBLE') 	   
	   if ret and visible then
	      base.m_simpleTV.Common.Wait(1000)
	    end
		
	   break 
	  else 
       if params.delayedShow > 0 then
	     delayedCount = delayedCount + 250
		 if delayedCount >= params.delayedShow then
		    params.delayedShow = 0
			base.m_simpleTV.OSD.ControlElement('ID_APLS_WAIT_TEXT','SET_VISIBLE',true,true)
		 end
	   end
	   
      end
	else 
	  if base.m_simpleTV.Common.WaitUserInput(500)==1 then 
	     base.m_simpleTV.OSD.ControlElement('ID_APLS_WAIT_TEXT1','SET_VALUE_TEXT',Cancelled)
	     base.m_simpleTV.OSD.ControlElement('ID_APLS_WAIT_TEXT1','SET_VALUE_TCOLOR',ARGB(250,255,0,0))
	     base.m_simpleTV.Http.RequestCancel(session)
	     base.m_simpleTV.Common.Wait(1000)
	     break 
      end
	end
 end
  
 HideWaitWindow() 
 return true
end 
--------------------------------------------------------------------

--------------------------------------------------------------------
--------------------------------------------------------------------
