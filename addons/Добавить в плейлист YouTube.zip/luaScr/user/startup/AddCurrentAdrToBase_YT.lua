-- Скрипт для добавления текущего адреса видео в плейлист "YouTube" https://www.youtube.com (29/2/20)
	if not m_simpleTV.User then
		m_simpleTV.User = {}
	end
	if not m_simpleTV.User.YT then
		m_simpleTV.User.YT = {}
	end
	local function ShowMessage(s)
		m_simpleTV.OSD.ShowMessageT({text = s, showTime = 8000, id = 'channelName'})
	end
	local function clean_adr(s)
			if not s then return end
		s = s:gsub('&isPlst=[^&]*', '')
		s = s:gsub('&isChPlst=[^&]*', '')
		s = s:gsub('&isLogo=[^&]*', '')
		s = s:gsub('&restart', '')
		local index = s:match('&index=(%d+)')
		if index == '1' then
			s = s:gsub('&index=%d+', '')
		end
	 return s
	end
	local function unescape_html(str)
		str = str:gsub('&#39;', '\'')
		str = str:gsub('&ndash;', '-')
		str = str:gsub('&#8217;', '\'')
		str = str:gsub('&raquo;', '"')
		str = str:gsub('&laquo;', '"')
		str = str:gsub('&lt;', '<')
		str = str:gsub('&gt;', '>')
		str = str:gsub('&quot;', '"')
		str = str:gsub('&apos;', '\'')
		str = str:gsub('&#(%d+);', function(n) return string.char(n) end)
		str = str:gsub('&#x(%d+);', function(n) return string.char(tonumber(n, 16)) end)
		str = str:gsub('&amp;', '&')
	 return str
	end
	local function clean_title(s)
		s = s:gsub('%%22', '\'')
		s = s:gsub('\\u0026', '&')
		s = s:gsub('\\n', ' ')
		s = unescape_html(s)
		s = s:gsub('"', '\'')
	 return s
	end
	local function clean_desc(d)
		d = d:gsub('%%22', '\'')
		d = d:gsub('\\u200f', '')
		d = d:gsub('\\u200e', '')
		d = d:gsub('\\r\\n', '\n')
		d = d:gsub('\\n\\n', '\n')
		d = d:gsub('\\n', '\n')
		d = d:gsub('\\r', '\n')
		d = unescape_html(d)
		d = d:gsub('"', '\'')
	 return d
	end
	local function findChannelIdByAddress(adr)
		if adr then
			local t = m_simpleTV.Database.GetTable('SELECT Channels.Id FROM Channels WHERE Channels.Address="' .. adr .. '" AND Channels.Id<268435455;')
				if t and t[1] and t[1].Id then
				 return t[1].Id
				end
		end
	 return nil
	end
	function AddCurrentAdrToBase_YT()
		local info = m_simpleTV.Control.GetCurrentChannelInfo()
			if not info or info.Id == - 1 then return end
			if not info.Address then return end
		if not info.MultiAddress then info.MultiAddress = '' end
			if not info.Address:match('^https?://[%a%.]*youtu[%.combe]')
				and not info.MultiAddress:match('^https?://[%a%.]*youtu[%.combe]')
				and not info.Address:match('^%s*%-')
			then
				ShowMessage('это не адрес YouTube')
			 return
			end
			if not (m_simpleTV.Control.GetState() == 3
				or m_simpleTV.Control.GetState() == 4)
				or not m_simpleTV.User.YT.vId
			then
				ShowMessage('не доступно')
			 return
			end
		local title, plst, pos, adr, logo, desc, GroupName
		if m_simpleTV.User.YT.isVideo == false then
			plst = true
		end
		if plst == true
			and m_simpleTV.User.YT.AddToBaseUrlinAdr
			and not findChannelIdByAddress(clean_adr(m_simpleTV.User.YT.AddToBaseUrlinAdr))
		then
			local ret = m_simpleTV.Interface.MessageBox('     добавить адрес\n【да】 - плейлиста\n【нет】 - видео', 'YouTube', 0x23)
				if ret == 2 then return end
			if ret == 6 then
				pos = 0
				title = m_simpleTV.User.YT.plstHeader
				adr = m_simpleTV.User.YT.AddToBaseUrlinAdr
				logo = 'https://i.ytimg.com/vi/' .. m_simpleTV.User.YT.AddToBaseVideoIdPlst .. '/hqdefault.jpg'
			else
				pos = (m_simpleTV.Control.GetPosition() or 0)
				title = m_simpleTV.User.YT.title
				adr = 'https://www.youtube.com/watch?v=' .. m_simpleTV.User.YT.vId
				logo = 'https://i.ytimg.com/vi/' .. m_simpleTV.User.YT.vId .. '/hqdefault.jpg'
				plst = false
			end
		else
			pos = (m_simpleTV.Control.GetPosition() or 0)
			title = m_simpleTV.User.YT.title
			adr = 'https://www.youtube.com/watch?v=' .. m_simpleTV.User.YT.vId
			logo = 'https://i.ytimg.com/vi/' .. m_simpleTV.User.YT.vId .. '/hqdefault.jpg'
			plst = false
		end
		local extFilter = 0
		local groupId = 0
		local typeMedia = m_simpleTV.PlayList.GetMediaMode()
		title = clean_title(title)
		adr = clean_adr(adr)
		if plst == true then
			plst = 'плейлист'
			desc = ''
			GroupName = 'YouTube'
		else
			plst = 'видео'
			desc = m_simpleTV.User.YT.desc or ''
			desc = clean_desc(desc)
			GroupName = 'YouTube'
		end
		if GroupName ~= '' then
			local t = m_simpleTV.Database.GetTable('SELECT Channels.Id, Channels.ExtFilter,Channels.TypeMedia FROM Channels WHERE (Channels.Name="' .. GroupName .. '" AND Channels.Id>268435455);')
			if t and t[1] then
				groupId = (t[1].Id or 0)
				extFilter = (t[1].ExtFilter or 0)
				if t[1].TypeMedia then
					typeMedia = t[1].TypeMedia
				end
			end
		end
		local channelId = findChannelIdByAddress(adr)
		if channelId then
				if m_simpleTV.Interface.MessageBox('Видео с таким адресом существует, переписать?', 'YouTube', 0x24) ~= 6 then return end
				if not m_simpleTV.Database.ExecuteSql('DELETE FROM Channels WHERE (Channels.Id=' .. channelId .. ');', true) then return end
		else
			t = m_simpleTV.Database.GetTable('SELECT (MAX(Channels.Id))+1 AS NewId FROM Channels WHERE Channels.Id<268435456 AND Channels.Id<>268435455;')
				if not t
					or not t[1]
					or not t[1].NewId
				then
				 return
				end
			channelId = t[1].NewId
		end
-- debug_in_file('id:' .. channelId .. '\ntitle:' .. title .. '\nadr:' .. adr .. '\ngr:' .. groupId .. '\nlogo:' .. logo .. '\npos:' .. pos .. '\nplst:' .. plst .. '\ndesc:' .. desc .. '\n')
		if m_simpleTV.Database.ExecuteSql('INSERT INTO Channels ([Id],[ChannelOrder],[Name],[Address],[Group],[Logo],[ExtFilter],[TypeMedia],[LastPosition],[Desc],[Title]) VALUES (' .. channelId .. ',' .. channelId .. ',"' .. title .. '","' .. adr .. '",' .. groupId .. ',"' .. logo .. '",' .. extFilter ..',' .. typeMedia .. ',' .. pos .. ',"' .. desc .. '","' .. plst .. '");')
		then
			title = 'ссылка на ' .. plst .. ' добавлена'
			ShowMessage(title)
			m_simpleTV.PlayList.Refresh()
		else
			title = 'не возможно добавить'
			ShowMessage(title)
		end
	end
	m_simpleTV.Interface.AddExtMenuT({name = 'Добавить в плейлист YouTube',
									luastring = 'AddCurrentAdrToBase_YT()',
									lua_as_scr = true, ctrlkey = 2,
									key = 0x20,
									image = m_simpleTV.MainScriptDir .. 'user/AddCurrentAdrToBase_YT/Img/menu.png'})
	m_simpleTV.Interface.AddExtMenuT({utf8 = false, name = '-'})