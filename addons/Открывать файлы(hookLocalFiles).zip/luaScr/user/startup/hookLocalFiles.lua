-- 28/2/19
--hookLocalFiles
if m_simpleTV.User==nil then m_simpleTV.User={} end
if m_simpleTV.User.hookLocalFiles==nil then m_simpleTV.User.hookLocalFiles={} end
if m_simpleTV.User.hookLocalFiles.Table==nil then m_simpleTV.User.hookLocalFiles.Table={} end
AddFileToExecute('getaddress',m_simpleTV.MainScriptDir .. "user/hookLocalFiles/getaddress.lua")
AddFileToExecute('onconfig',m_simpleTV.MainScriptDir .. "user/hookLocalFiles/initconfig.lua")
local function getConfigVal(key)
 return m_simpleTV.Config.GetValue(key,"hookLocalFilesConf.ini")
end
local value
  value=getConfigVal('hookLocalFilesEnabledChk')
  if value~=nil then
      if tonumber(value)==1 then
         m_simpleTV.User.hookLocalFiles.isHook=1
      else
         m_simpleTV.User.hookLocalFiles.isHook=0
      end
  end
  value=getConfigVal('hookLocalFilesVideoChk')
  if value~=nil then
      if tonumber(value)==1 then
         m_simpleTV.User.hookLocalFiles.isVideo=1
      else
         m_simpleTV.User.hookLocalFiles.isVideo=0
      end
  end
  value = getConfigVal('hookLocalFilesVideo')
  if value~=nil then
		m_simpleTV.User.hookLocalFiles.Video=value
  end
  value=getConfigVal('hookLocalFilesAudioChk')
  if value~=nil then
      if tonumber(value)==1 then
         m_simpleTV.User.hookLocalFiles.isAudio=1
      else
         m_simpleTV.User.hookLocalFiles.isAudio=0
      end
  end
  value = getConfigVal('hookLocalFilesAudio')
  if value~=nil then
		m_simpleTV.User.hookLocalFiles.Audio=value
  end
  value=getConfigVal('hookLocalFilesImageChk')
  if value~=nil then
      if tonumber(value)==1 then
         m_simpleTV.User.hookLocalFiles.isImage=1
      else
         m_simpleTV.User.hookLocalFiles.isImage=0
      end
  end
  value = getConfigVal('hookLocalFilesImage')
  if value~=nil then
		m_simpleTV.User.hookLocalFiles.Image=value
  end
  value = getConfigVal('hookLocalFilesImageDur')
  if value~=nil then
		m_simpleTV.User.hookLocalFiles.ImageDuration=value
  end