-- (28/2/19)
local function getConfigVal(key)
 return m_simpleTV.Config.GetValue(key,"hookLocalFilesConf.ini")
end
local function setConfigVal(key,val)
  m_simpleTV.Config.SetValue(key,val,"hookLocalFilesConf.ini")
end
function OnNavigateComplete(Object)
  local value
  value= getConfigVal("hookLocalFilesEnabledChk") or 0
  m_simpleTV.Dialog.SetCheckBoxValue(Object,'hookLocalFilesEnabledChk',value)
  value= getConfigVal("hookLocalFilesVideoChk") or 1
  m_simpleTV.Dialog.SetCheckBoxValue(Object,'hookLocalFilesVideoChk',value)
  value= getConfigVal("hookLocalFilesVideo") or 'ts,mp4,mkv,avi,vob,wmv'
  m_simpleTV.Dialog.SetElementValueString(Object,'hookLocalFilesVideo',value)
  value= getConfigVal("hookLocalFilesAudioChk") or 1
  m_simpleTV.Dialog.SetCheckBoxValue(Object,'hookLocalFilesAudioChk',value)
  value= getConfigVal("hookLocalFilesAudio") or 'mp3,ogg,flac,wma'
  m_simpleTV.Dialog.SetElementValueString(Object,'hookLocalFilesAudio',value)
  value= getConfigVal("hookLocalFilesImageChk") or 1
  m_simpleTV.Dialog.SetCheckBoxValue(Object,'hookLocalFilesImageChk',value)
  value= getConfigVal("hookLocalFilesImage") or 'gif,jpg,jpeg,png'
  m_simpleTV.Dialog.SetElementValueString(Object,'hookLocalFilesImage',value)
  value= getConfigVal("hookLocalFilesImageDur") or 5
  m_simpleTV.Dialog.SetElementValueString(Object,'hookLocalFilesImageDur',value)
  m_simpleTV.Dialog.AddEventHandler(Object,'OnClick','hookLocalFilesButtonDef','OnClickhookLocalFilesButtonDef')
end
------------------------------------------------------------------
function OnOk(Object)
local value
  value=m_simpleTV.Dialog.GetCheckBoxValue(Object,'hookLocalFilesEnabledChk')
  if value~=nil then
      setConfigVal("hookLocalFilesEnabledChk",value)
      if tonumber(value)==1 then
         m_simpleTV.User.hookLocalFiles.isHook=1
      else
         m_simpleTV.User.hookLocalFiles.isHook=0
      end
  end
  value=m_simpleTV.Dialog.GetCheckBoxValue(Object,'hookLocalFilesVideoChk')
  if value~=nil then
      setConfigVal("hookLocalFilesVideoChk",value)
      if tonumber(value)==1 then
         m_simpleTV.User.hookLocalFiles.isVideo=1
      else
         m_simpleTV.User.hookLocalFiles.isVideo=0
      end
  end
  value = m_simpleTV.Dialog.GetElementValueString(Object,'hookLocalFilesVideo')
  if value~=nil then
		setConfigVal("hookLocalFilesVideo",value)
		m_simpleTV.User.hookLocalFiles.Video=value
  end
  value=m_simpleTV.Dialog.GetCheckBoxValue(Object,'hookLocalFilesAudioChk')
  if value~=nil then
      setConfigVal("hookLocalFilesAudioChk",value)
      if tonumber(value)==1 then
         m_simpleTV.User.hookLocalFiles.isAudio=1
      else
         m_simpleTV.User.hookLocalFiles.isAudio=0
      end
  end
  value = m_simpleTV.Dialog.GetElementValueString(Object,'hookLocalFilesAudio')
  if value~=nil then
		setConfigVal("hookLocalFilesAudio",value)
		m_simpleTV.User.hookLocalFiles.Audio=value
  end
  value=m_simpleTV.Dialog.GetCheckBoxValue(Object,'hookLocalFilesImageChk')
  if value~=nil then
      setConfigVal("hookLocalFilesImageChk",value)
      if tonumber(value)==1 then
         m_simpleTV.User.hookLocalFiles.isImage=1
      else
         m_simpleTV.User.hookLocalFiles.isImage=0
      end
  end
  value = m_simpleTV.Dialog.GetElementValueString(Object,'hookLocalFilesImage')
  if value~=nil then
		setConfigVal("hookLocalFilesImage",value)
		m_simpleTV.User.hookLocalFiles.Image=value
  end
  value = m_simpleTV.Dialog.GetElementValueString(Object,'hookLocalFilesImageDur')
  if value~=nil then
		setConfigVal("hookLocalFilesImageDur",value)
		m_simpleTV.User.hookLocalFiles.ImageDuration=value
  end
end
------------------------------------------------------------------
function OnClickhookLocalFilesButtonDef(Object)
  m_simpleTV.Dialog.SetCheckBoxValue(Object,'hookLocalFilesEnabledChk',0)
  m_simpleTV.Dialog.SetCheckBoxValue(Object,'hookLocalFilesVideoChk',1)
  m_simpleTV.Dialog.SetElementText(Object,'hookLocalFilesVideo','ts,mp4,mkv,avi,vob,wmv')
  m_simpleTV.Dialog.SetCheckBoxValue(Object,'hookLocalFilesAudioChk',1)
  m_simpleTV.Dialog.SetElementText(Object,'hookLocalFilesAudio','mp3,ogg,flac,wma')
  m_simpleTV.Dialog.SetCheckBoxValue(Object,'hookLocalFilesImageChk',1)
  m_simpleTV.Dialog.SetElementText(Object,'hookLocalFilesImage','gif,jpg,jpeg,png')
  m_simpleTV.Dialog.SetElementText(Object,'hookLocalFilesImageDur',5)
end
------------------------------------------------------------------