
function OnOk()
  if m_simpleTV.User.hookLocalFiles.Random~=nil then
     m_simpleTV.User.hookLocalFiles.Random = false
  end
end

function OnCancel()
end

