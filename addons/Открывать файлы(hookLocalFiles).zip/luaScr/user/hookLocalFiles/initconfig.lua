m_simpleTV.Config.AddExtDialog('Hook Local Files',m_simpleTV.MainScriptDir .. 'user\\hookLocalFiles\\configDialog.htm','user\\hookLocalFiles\\configDialog.lua')
