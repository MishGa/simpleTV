-- Открывать файлы(hookLocalFiles) (22/4/20)
	if not TVSources_var or TVSources_var and not TVSources_var.ChangeAdress then
		m_simpleTV.Control.EventPlayingInterval = 3000
	end
	if not m_simpleTV.User.hookLocalFiles.isHook then
		m_simpleTV.User.hookLocalFiles.isHook = 0
	end
	local isHook = tonumber(m_simpleTV.User.hookLocalFiles.isHook)
		if isHook ~= 1 then return end
	if not m_simpleTV.User.hookLocalFiles.isVideo then
		m_simpleTV.User.hookLocalFiles.isVideo = 1
	end
	if not m_simpleTV.User.hookLocalFiles.isAudio then
		m_simpleTV.User.hookLocalFiles.isAudio = 1
	end
	if not m_simpleTV.User.hookLocalFiles.isImage then
		m_simpleTV.User.hookLocalFiles.isImage = 1
	end
	local preset1 = ''
	local preset2 = ''
	local preset3 = ''
	if tonumber(m_simpleTV.User.hookLocalFiles.isVideo) == 1 then
		preset1 = m_simpleTV.User.hookLocalFiles.Video or ''
		if preset1 ~= '' and not preset1:match('^.+,$') then
			preset1 = preset1 .. ','
		end
	end
	if tonumber(m_simpleTV.User.hookLocalFiles.isAudio) == 1 then
		preset2 = m_simpleTV.User.hookLocalFiles.Audio or ''
		if preset2 ~= '' and not preset2:match('^.+,$') then
			preset2 = preset2 .. ','
		end
	end
	if tonumber(m_simpleTV.User.hookLocalFiles.isImage) == 1 then
		preset3 = m_simpleTV.User.hookLocalFiles.Image or ''
		if preset3 ~= '' and not preset3:match('^.+,$') then
			preset3 = preset3 .. ','
		end
	end
	local fmt = preset1 .. preset2 .. preset3
		if fmt == '' then return end
	if not m_simpleTV.User.hookLocalFiles.ImageDuration then
		m_simpleTV.User.hookLocalFiles.ImageDuration = 5
	end
	local img_dur = m_simpleTV.User.hookLocalFiles.ImageDuration
	local inAdr = m_simpleTV.Control.CurrentAdress
		if not inAdr then return end
		if not inAdr:match('^.:')
			and not inAdr:match('^hookLocalFiles')
		then
		 return
		end
	local tempDir = os.getenv('TEMP') or ''
		if inAdr:match(tempDir:gsub('\\', '\\\\')) or inAdr:match(m_simpleTV.Common.GetMainPath(2)) then return end
	m_simpleTV.Control.ChangeAdress = 'Yes'
	m_simpleTV.Control.CurrentAdress = ''
	local optExt = '$OPT:POSITIONTOCONTINUE=0$OPT:image-duration=' .. img_dur
	local title
		if inAdr:match('^hookLocalFiles') then
			if m_simpleTV.User.hookLocalFiles.Tabletitle then
				local index = m_simpleTV.Control.GetMultiAddressIndex()
				if index then
					title = m_simpleTV.User.hookLocalFiles.Tabletitle[index].Name
					title = m_simpleTV.Common.multiByteToUTF8(title)
					if m_simpleTV.Control.CurrentTitle_UTF8 then
						m_simpleTV.Control.CurrentTitle_UTF8 = title
					end
					m_simpleTV.OSD.ShowMessageT({text = title, color = ARGB(255, 155, 155, 255), showTime = 1000 * 5, id = 'channelName'})
				end
			end
			m_simpleTV.Control.CurrentAdress = inAdr:gsub('^hookLocalFiles', '') .. optExt
		 return
		end
	local function trim(s)
	 return s:gsub('^%s*(.-)%s*$', '%1')
	end
	local tab = {}
	for w in string.gmatch(fmt, '([^%s,]+)') do
		w = '%.' .. w .. '$'
		table.insert(tab, w)
	end
	local function CheckExt(adr)
		for i, v in ipairs(tab) do
			local a = adr
			if string.match(a, v) or string.match(a, string.upper(v)) then
			 return true
			end
		end
	 return false
	end
		if not CheckExt(trim(inAdr)) then
			m_simpleTV.Control.ChangeAdress = 'No'
			m_simpleTV.Control.CurrentAdress = inAdr
			dofile(m_simpleTV.MainScriptDir .. "user\\video\\video.lua")
		 return
		end
	m_simpleTV.Control.ChangeAdress = 'Yes'
	m_simpleTV.Control.CurrentAdress = 'error'
	inAdr = inAdr:gsub('\\', '/')
	local path = inAdr:gsub('(.+/).-$', '%1')
	local t, i = {}, 1
	local adr, index
	require 'lfs'
		for file in lfs.dir(path) do
			adr = path .. file
			-- if lfs.attributes(adr, 'mode') == 'file' then
				if CheckExt(adr) then
					t[i] = {}
					t[i].Id = i
					if file:match('%?') then
						t[i].Adress = 'hookLocalFiles' .. adr
					else
						t[i].Adress = 'hookLocalFilesfile:///' .. adr
					end
					file = file:gsub('%?', ' ')
					file = file:gsub('_', ' ')
					t[i].Name = file
					if trim(inAdr) == adr then
						index = i
					end
					i = i + 1
				end
			-- end
		end
		if i == 1 then return end
	m_simpleTV.User.hookLocalFiles.Tabletitle = t
	local retAdr = t[index].Adress
	title = m_simpleTV.Common.multiByteToUTF8(t[index].Name)
	if m_simpleTV.Control.CurrentTitle_UTF8 then
		m_simpleTV.Control.CurrentTitle_UTF8 = title
	end
	path = path:gsub('/$', '')
	path = path:gsub('/', '\\')
	t.ExtParams = {AutoNumberFormat = '%1. %2'}
	t.ExtButton1 = {ButtonEnable = true, ButtonName = '', ButtonScript = 'm_simpleTV.Control.ExecuteAction(116)'}
	m_simpleTV.OSD.ShowSelect(path, index - 1, t, 5000, 32 + 64)
	m_simpleTV.OSD.ShowMessageT({text = title, color = ARGB(255, 155, 155, 255), showTime = 1000 * 5, id = 'channelName'})
	m_simpleTV.Control.CurrentAdress = retAdr:gsub('^hookLocalFiles', '') .. optExt
-- debug_in_file(retAdr .. '\n')